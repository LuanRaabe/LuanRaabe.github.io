# GameEscola
<h2>Projeto de Gamificação do ensino em escolas</h2>

<p>Neste projeto criamos uma plataforma web-mobile para gestão de atividades escolares pelo professor e pela escola.<br/>
A plataforma fornece ferramentas com elementos de jogos, como conquistas e raqueamentos, para incentivar o engajamento estudantil.<br/>
No momento estamos criando o front-end das telas do professor.</p>

<span>Proximos passos:</span>
<ol>
<li>Back-end do fluxo de trabalho para o cliente professor.</li>
<li>Publicação da versão inicial.</li>
<li>Front e Back-end do fluxo para o  cliente estudante.</li>
<li>Publicação de nova versão.</li>
<li>Front e Back-end do fluxo para o  cliente cordenação escolar.</li>
<li>Publicação de nova versão.</li>
<li>Front e Back-end do fluxo para o  cliente responsaveis.</li>
<li>Publicação de nova versão.</li>
</ol>

<span>Autores (ordem alfabetica)</span>
<ul>
<li>David Henrique Souza Santana</li>
<li>Luan Raabe Pereira Ferreira</li>
<li>Marcos Douglas da Silva Martins</li>
<li>Plinio Figueiredo dos Santos</li>
<li>Stênio Vinicios de Medeiros</li>
</ul>
